criaCartao(
    'HISTORIA',
    'Em que ano ocorreu a Independência do Brasil?',
    '1822'
)

criaCartao(
    'HISTORIA',
    'Qual evento marcou o início da Segunda Guerra Mundial?',
    'A invasão da Polônia pela Alemanha'
)

criaCartao(
    'LINGUA INGLESA',
    'Qual significado da gíria tbh?',
    'Para ser honesto "to be honest"'
)

criaCartao(
    'LINGUA INGLESA',
    'Qual o signiicado da gíria fr?',
    'Significa afirmar algo verdadeiro "for real"'
)
criaCartao(
    'LINGUA PORTUGUESA',
    'Qual é o autor da obra "Dom Casmurro" ?',
    'Machado De Assis'
)

criaCartao(
    'LINGUA PORTUGUESA',
    'Qual é o nome da obra mais famosa de Jose Alencar?',
    'O Guarani'
)